package com.fatec.projeto.projeto2025;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto2025ApplicationTests {

	@Test
	void contextLoads() {
	}

}
